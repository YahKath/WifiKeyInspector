import os
from cryptography.fernet import Fernet
import colorama 

def generate_key():
    key = Fernet.generate_key()
    with open("secret.key", "wb") as key_file:
        key_file.write(key)
    return key


def load_key():
    return open("secret.key", "rb").read()

def save_password(service, password):
    key = load_key()
    cipher_suite = Fernet(key)
    encrypted_password = cipher_suite.encrypt(password.encode())
    
    with open(f"{service}.pwd", "wb") as password_file:
        password_file.write(encrypted_password)
    print(colorama.Fore.GREEN + f"Password for {service} Saved.")

def load_password(service):
    key = load_key()
    cipher_suite = Fernet(key)
    
    try:
        with open(f"{service}.pwd", "rb") as password_file:
            encrypted_password = password_file.read()
        decrypted_password = cipher_suite.decrypt(encrypted_password).decode()
        print(f"Heslo pre {service} je {decrypted_password}")
    except FileNotFoundError:
        print(colorama.Fore.RED + f"Password not found {service}.")

# Created by YahKath
def main():
    if not os.path.exists("secret.key"):
        generate_key()

    while True:
        print(colorama.Fore.RED + "\nPassword Manager")
        print(colorama.Fore.RED + "1. Save password")
        print(colorama.Fore.RED + "2. Load password")
        print(colorama.Fore.RED + "3. Exit")
        
        choice = input("Choose an option: ")
        
        if choice == "1":
            service = input("Enter the service name: ")
            password = input("Enter the password: ")
            save_password(service, password)
        elif choice == "2":
            service = input("Enter the service name: ")
            load_password(service)
        elif choice == "3":
            break
        else:
            print(colorama.Fore.RED + "Wrong.")

if __name__ == "__main__":
    main()
