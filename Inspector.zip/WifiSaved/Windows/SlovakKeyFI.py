import subprocess
from colorama import init, Fore, Style 

init(autoreset=True)

def print_large_text(text):
    ascii_art_dict = {
        'K': [
            "K   K ",
            "K  K  ",
            "KKK   ",
            "K  K  ",
            "K   K ",
        ],
        'E': [
            "EEEEE ",
            "E     ",
            "EEE   ",
            "E     ",
            "EEEEE ",
        ],
        'Y': [
            "Y   Y ",
            " Y Y  ",
            "  Y   ",
            "  Y   ",
            "  Y   ",
        ],
        'F': [
            "FFFFF ",
            "F     ",
            "FFFF  ",
            "F     ",
            "F     ",
        ],
        'I': [
            "IIIII ",
            "  I   ",
            "  I   ",
            "  I   ",
            "IIIII ",
        ],
    }

    lines = [""] * 5  

    for char in text.upper():
        if char in ascii_art_dict:
            for i in range(5):
                lines[i] += ascii_art_dict[char][i] + "  "
        else:
            for i in range(5):
                lines[i] += "      "

    for line in lines:
        print(line)


print_large_text(Fore.RED + "KeyFi")
print(Fore.RED + "Autor: yahkath")

      
def get_wifi_profiles():
    result = subprocess.run(['netsh', 'wlan', 'show', 'profiles'], capture_output=True, text=True)
    profiles = []
    for line in result.stdout.split('\n'):
        if "All User Profile" in line:
            profile = line.split(":")[1].strip()
            profiles.append(profile)
    return profiles

def get_wifi_password(profile):
    result = subprocess.run(['netsh', 'wlan', 'show', 'profile', f'name={profile}', 'key=clear'], capture_output=True, text=True)
    for line in result.stdout.split('\n'):
        if "Key Content" in line:
            password = line.split(":")[1].strip()
            return password
    return None

def main():
    profiles = get_wifi_profiles()
    if not profiles:
        print(Fore.RED + "Wifi neexistuje :/.")
        return

    print(Fore.GREEN + "Ulozene wifi")
    for idx, profile in enumerate(profiles):
        print(f"{idx + 1}. {profile}")

    try:
        choice = int(input("Vyber wifi : "))
        if choice < 1 or choice > len(profiles):
            print("XXXXXXXXXXX")
            return
        selected_profile = profiles[choice - 1]
        password = get_wifi_password(selected_profile)
        if password:
            print(Fore.GREEN + f"Heslo: {selected_profile}: {password}")
        else:
            print("Wifi asi neexistuje :(.")
    except ValueError:
        
        restart = input("Zle cislo skusit znovu ? (y,yes/N,no): .") .strip().lower()
        if restart not in ('yes', 'y'):
            print("BYE")
#Created by YahKath
if __name__ == "__main__":
    main()
